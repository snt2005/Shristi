<?php
session_start();
require_once '../config/database.php';

// Enable error reporting and logging
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/admin_errors.log'); // Create a separate log for admin actions

header('Content-Type: application/json');

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['user_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'User ID is required']);
    exit;
}

error_log("Admin approval attempt for user_id: " . $data['user_id']);

try {
    $pdo = getConnection();
    $pdo->beginTransaction();

    // Get user information
    $stmt = $pdo->prepare("SELECT user_id, role, status FROM users WHERE user_id = ? AND status = 'pending'");
    $stmt->execute([$data['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        error_log("Approval failed: User " . $data['user_id'] . " not found or already approved.");
        throw new Exception('User not found or already approved');
    }

    error_log("User found for approval: " . print_r($user, true));

    // Update user status in users table
    $stmt = $pdo->prepare("UPDATE users SET status = 'active' WHERE user_id = ?");
    $userUpdateSuccess = $stmt->execute([$data['user_id']]);
    error_log("User status update result for user " . $data['user_id'] . ": " . ($userUpdateSuccess ? 'Success' : 'Failed'));

    // If user is a hospital, update hospital status as well
    if ($user['role'] === 'hospital') {
        error_log("User is a hospital, attempting to update hospital status...");
        $stmt = $pdo->prepare("UPDATE hospitals SET status = 'active' WHERE user_id = ?");
        $hospitalUpdateSuccess = $stmt->execute([$data['user_id']]);
        error_log("Hospital status update result for user " . $data['user_id'] . ": " . ($hospitalUpdateSuccess ? 'Success' : 'Failed'));

        // Optional: Verify hospital status after update
        $checkHospitalStmt = $pdo->prepare("SELECT status FROM hospitals WHERE user_id = ?");
        $checkHospitalStmt->execute([$data['user_id']]);
        $hospitalStatus = $checkHospitalStmt->fetchColumn();
        error_log("Hospital status after update attempt: " . ($hospitalStatus ? $hospitalStatus : 'Not found'));

    }

    // Create notification for the user
    $stmt = $pdo->prepare("
        INSERT INTO notifications (user_id, title, message, type, created_at)
        VALUES (?, ?, ?, ?, NOW())
    ");
    // Assuming 'full_name' is available for the user (it should be after recent database changes)
    // If not, you might fetch it here or use a generic name
    $notificationTitle = 'Account Approved';
    $notificationMessage = 'Your registration has been approved. You can now log in to your account.';
    $notificationType = 'success';
    
    $stmt->execute([
        $data['user_id'],
        $notificationTitle,
        $notificationMessage,
        $notificationType
    ]);
    error_log("Notification sent to user " . $data['user_id']);

    $pdo->commit();
    error_log("Approval transaction committed for user " . $data['user_id']);
    echo json_encode(['success' => true]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Approval failed for user " . $data['user_id'] . ": " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
} 