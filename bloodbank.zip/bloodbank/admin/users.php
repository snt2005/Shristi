<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.html');
    exit;
}

$pdo = getConnection();

// Get all users with their role-specific information
$stmt = $pdo->prepare("
    SELECT u.*, 
           CASE 
               WHEN u.role = 'hospital' THEN h.name 
               WHEN u.role = 'donor' THEN d.name 
               WHEN u.role = 'recipient' THEN r.name 
           END as full_name,
           CASE 
               WHEN u.role = 'hospital' THEN h.license_number 
               ELSE NULL 
           END as license_number
    FROM users u
    LEFT JOIN hospitals h ON u.user_id = h.user_id
    LEFT JOIN donors d ON u.user_id = d.user_id
    LEFT JOIN recipients r ON u.user_id = r.user_id
    ORDER BY u.created_at DESC
");
$stmt->execute();
$users = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Blood Bank Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Blood Bank Admin</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../admin_dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="users.php">Users</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="hospitals.php">Hospitals</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="blood_units.php">Blood Units</a>
                    </li>
                </ul>
                <div class="d-flex">
                    <a href="../auth/logout.php" class="btn btn-light">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Manage Users</h5>
                <div class="btn-group">
                    <button type="button" class="btn btn-primary" onclick="filterUsers('all')">All</button>
                    <button type="button" class="btn btn-outline-primary" onclick="filterUsers('hospital')">Hospitals</button>
                    <button type="button" class="btn btn-outline-primary" onclick="filterUsers('donor')">Donors</button>
                    <button type="button" class="btn btn-outline-primary" onclick="filterUsers('recipient')">Recipients</button>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Registration Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr class="user-row" data-role="<?php echo $user['role']; ?>">
                                    <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td>
                                        <span class="badge bg-<?php 
                                            echo $user['role'] === 'hospital' ? 'primary' : 
                                                ($user['role'] === 'donor' ? 'success' : 'info'); 
                                        ?>">
                                            <?php echo ucfirst($user['role']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php 
                                            echo $user['status'] === 'active' ? 'success' : 
                                                ($user['status'] === 'pending' ? 'warning' : 'danger'); 
                                        ?>">
                                            <?php echo ucfirst($user['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                    <td>
                                        <?php if ($user['status'] === 'pending'): ?>
                                            <button class="btn btn-sm btn-success" onclick="approveUser(<?php echo $user['user_id']; ?>)">
                                                <i class="bi bi-check-lg"></i> Approve
                                            </button>
                                            <button class="btn btn-sm btn-danger" onclick="rejectUser(<?php echo $user['user_id']; ?>)">
                                                <i class="bi bi-x-lg"></i> Reject
                                            </button>
                                        <?php else: ?>
                                            <button class="btn btn-sm btn-warning" onclick="toggleUserStatus(<?php echo $user['user_id']; ?>, '<?php echo $user['status']; ?>')">
                                                <i class="bi bi-toggle-on"></i> <?php echo $user['status'] === 'active' ? 'Deactivate' : 'Activate'; ?>
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function filterUsers(role) {
            const rows = document.querySelectorAll('.user-row');
            rows.forEach(row => {
                if (role === 'all' || row.dataset.role === role) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        function approveUser(userId) {
            if (confirm('Are you sure you want to approve this user?')) {
                fetch('approve_registration.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ user_id: userId })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('User approved successfully');
                        location.reload();
                    } else {
                        alert(data.error || 'Failed to approve user');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while approving the user');
                });
            }
        }

        function rejectUser(userId) {
            if (confirm('Are you sure you want to reject this user?')) {
                fetch('reject_registration.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ user_id: userId })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('User rejected successfully');
                        location.reload();
                    } else {
                        alert(data.error || 'Failed to reject user');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while rejecting the user');
                });
            }
        }

        function toggleUserStatus(userId, currentStatus) {
            const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
            if (confirm(`Are you sure you want to ${newStatus === 'active' ? 'activate' : 'deactivate'} this user?`)) {
                fetch('toggle_user_status.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ 
                        user_id: userId,
                        status: newStatus
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(`User ${newStatus === 'active' ? 'activated' : 'deactivated'} successfully`);
                        location.reload();
                    } else {
                        alert(data.error || 'Failed to update user status');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while updating user status');
                });
            }
        }
    </script>
</body>
</html> 