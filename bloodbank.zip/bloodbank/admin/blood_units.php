<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.html');
    exit;
}

$pdo = getConnection();

$error = null;
$hospitalsWithInventory = [];

try {
    // Get available blood inventory counts from all active hospitals
    $stmt = $pdo->prepare("
        SELECT 
            h.hospital_id,
            h.name as hospital_name,
            h.city,
            h.contact,
            hic.blood_group,
            hic.component_type,
            hic.available_count
        FROM hospitals h
        JOIN hospital_inventory_counts hic ON h.hospital_id = hic.hospital_id
        WHERE h.status = 'active' AND hic.available_count > 0
        ORDER BY h.name, hic.blood_group, hic.component_type
    ");
    $stmt->execute();
    $hospitalInventory = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Group inventory by hospital
    foreach ($hospitalInventory as $item) {
        $hospitalId = $item['hospital_id'];
        if (!isset($hospitalsWithInventory[$hospitalId])) {
            $hospitalsWithInventory[$hospitalId] = [
                'name' => $item['hospital_name'],
                'city' => $item['city'],
                'contact' => $item['contact'],
                'inventory' => []
            ];
        }
         // Group inventory by blood group within the hospital
        if (!isset($hospitalsWithInventory[$hospitalId]['inventory'][$item['blood_group']])) {
             $hospitalsWithInventory[$hospitalId]['inventory'][$item['blood_group']] = [];
        }
        $hospitalsWithInventory[$hospitalId]['inventory'][$item['blood_group']][] = [
            'component_type' => $item['component_type'],
            'available_count' => $item['available_count']
        ];
    }

} catch (PDOException $e) {
    error_log("Admin blood units error: " . $e->getMessage());
    $error = "An error occurred while loading hospital inventory.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital Inventory - Blood Bank Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Blood Bank Admin</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../admin_dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">Users</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="hospitals.php">Hospitals</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="blood_units.php">Hospital Inventory</a>
                    </li>
                </ul>
                <div class="d-flex">
                    <a href="../auth/logout.php" class="btn btn-light">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h2>Hospital Blood Inventory</h2>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if (empty($hospitalsWithInventory)): ?>
            <p class="text-center">No hospital inventory data found.</p>
        <?php else: ?>
            <?php foreach ($hospitalsWithInventory as $hospitalId => $hospital): ?>
                <div class="card mb-3">
                    <div class="card-header">
                        <h6><?php echo htmlspecialchars($hospital['name']); ?> (<?php echo htmlspecialchars($hospital['city']); ?>)</h6>
                    </div>
                    <div class="card-body">
                        <p><b>Contact:</b> <?php echo htmlspecialchars($hospital['contact']); ?></p>
                        <h6>Available Inventory:</h6>
                        <ul>
                            <?php foreach ($hospital['inventory'] as $bloodGroup => $componentTypes): ?>
                                <li><b><?php echo htmlspecialchars($bloodGroup); ?>:</b>
                                    <ul>
                                        <?php foreach ($componentTypes as $item): ?>
                                            <li><?php echo htmlspecialchars(ucfirst($item['component_type'])); ?>: <?php echo htmlspecialchars($item['available_count']); ?> units</li>
                                        <?php endforeach; ?>
                                    </ul>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // No specific JavaScript needed for this display page
    </script>
</body>
</html> 