<?php
session_start();
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $recipient_id = $_POST['recipient_id'];
        $hospital_id = $_POST['hospital_id'];
        $blood_group = $_POST['blood_group'];
        $units_required = $_POST['units_required'];

        $stmt = $pdo->prepare("INSERT INTO blood_requests (recipient_id, hospital_id, blood_group, units_required) 
                              VALUES (?, ?, ?, ?)");
        $stmt->execute([$recipient_id, $hospital_id, $blood_group, $units_required]);

        echo json_encode(['status' => 'success', 'message' => 'Blood request created successfully']);
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}
?> 