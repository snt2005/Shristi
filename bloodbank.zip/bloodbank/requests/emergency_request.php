<?php
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $requester_name = $_POST['requester_name'];
        $contact = $_POST['contact'];
        $blood_group = $_POST['blood_group'];
        $urgency_level = $_POST['urgency_level'];
        $reason = $_POST['reason'];

        $stmt = $pdo->prepare("INSERT INTO emergency_requests (requester_name, contact, blood_group, urgency_level, reason) 
                              VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$requester_name, $contact, $blood_group, $urgency_level, $reason]);

        echo json_encode(['status' => 'success', 'message' => 'Emergency request submitted successfully']);
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}
?> 