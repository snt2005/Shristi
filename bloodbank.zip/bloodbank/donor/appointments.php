<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is a donor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'donor') {
    header('Location: ../login.html');
    exit;
}

try {
    $pdo = getConnection();
    
    // Get donor information
    $stmt = $pdo->prepare("
        SELECT d.*, u.email, u.username
        FROM donors d
        JOIN users u ON d.user_id = u.user_id
        WHERE d.user_id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $donor = $stmt->fetch(PDO::FETCH_ASSOC);

    // Get available hospitals
    $stmt = $pdo->prepare("
        SELECT hospital_id, name, address, operating_hours
        FROM hospitals
        WHERE status = 'active'
        ORDER BY name
    ");
    $stmt->execute();
    $hospitals = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get upcoming appointments
    $stmt = $pdo->prepare("
        SELECT a.*, h.name as hospital_name
        FROM appointments a
        JOIN hospitals h ON a.hospital_id = h.hospital_id
        WHERE a.donor_id = ? AND a.appointment_date >= CURDATE()
        ORDER BY a.appointment_date, a.appointment_time
    ");
    $stmt->execute([$donor['donor_id']]);
    $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Appointments page error: " . $e->getMessage());
    $error = "An error occurred while loading the appointments page.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointments - Blood Bank Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Blood Bank Management System</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../donor_dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="appointments.php">Appointments</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="history.php">Donation History</a>
                    </li>
                </ul>
                <div class="d-flex">
                    <a href="../auth/logout.php" class="btn btn-light">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="row">
            <!-- Appointment Form -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Schedule New Appointment</h5>
                        <form id="appointmentForm" onsubmit="return scheduleAppointment(event)">
                            <div class="mb-3">
                                <label for="hospital" class="form-label">Select Hospital</label>
                                <select class="form-select" id="hospital" name="hospital" required>
                                    <option value="">Choose a hospital...</option>
                                    <?php foreach ($hospitals as $hospital): ?>
                                        <option value="<?php echo $hospital['hospital_id']; ?>">
                                            <?php echo htmlspecialchars($hospital['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="appointmentDate" class="form-label">Select Date</label>
                                <input type="text" class="form-control" id="appointmentDate" required>
                            </div>
                            <div class="mb-3">
                                <label for="appointmentTime" class="form-label">Select Time</label>
                                <select class="form-select" id="appointmentTime" required>
                                    <option value="">Choose a time...</option>
                                    <option value="09:00">9:00 AM</option>
                                    <option value="10:00">10:00 AM</option>
                                    <option value="11:00">11:00 AM</option>
                                    <option value="14:00">2:00 PM</option>
                                    <option value="15:00">3:00 PM</option>
                                    <option value="16:00">4:00 PM</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="notes" class="form-label">Additional Notes</label>
                                <textarea class="form-control" id="notes" rows="3"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Schedule Appointment</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Upcoming Appointments -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Upcoming Appointments</h5>
                        <?php if (empty($appointments)): ?>
                            <p>No upcoming appointments.</p>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Time</th>
                                            <th>Hospital</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($appointments as $appointment): ?>
                                            <tr>
                                                <td><?php echo date('M d, Y', strtotime($appointment['appointment_date'])); ?></td>
                                                <td><?php echo date('h:i A', strtotime($appointment['appointment_time'])); ?></td>
                                                <td><?php echo htmlspecialchars($appointment['hospital_name']); ?></td>
                                                <td>
                                                    <span class="badge bg-<?php 
                                                        echo $appointment['status'] === 'scheduled' ? 'primary' : 
                                                            ($appointment['status'] === 'completed' ? 'success' : 
                                                            ($appointment['status'] === 'cancelled' ? 'danger' : 'warning')); 
                                                    ?>">
                                                        <?php echo ucfirst($appointment['status']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php if ($appointment['status'] === 'scheduled'): ?>
                                                        <button onclick="cancelAppointment(<?php echo $appointment['appointment_id']; ?>)" 
                                                                class="btn btn-sm btn-danger">
                                                            Cancel
                                                        </button>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        // Initialize date picker
        flatpickr("#appointmentDate", {
            minDate: "today",
            maxDate: new Date().fp_incr(30), // Allow booking up to 30 days in advance
            disable: [
                function(date) {
                    // Disable weekends
                    return (date.getDay() === 0 || date.getDay() === 6);
                }
            ],
            dateFormat: "Y-m-d"
        });

        function scheduleAppointment(event) {
            event.preventDefault();
            
            const hospital = document.getElementById('hospital').value;
            const date = document.getElementById('appointmentDate').value;
            const time = document.getElementById('appointmentTime').value;
            const notes = document.getElementById('notes').value;

            // Disable submit button
            const submitButton = event.target.querySelector('button[type="submit"]');
            submitButton.disabled = true;
            submitButton.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Scheduling...';

            fetch('schedule_appointment.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    hospital_id: hospital,
                    appointment_date: date,
                    appointment_time: time,
                    notes: notes
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Appointment scheduled successfully!');
                    window.location.reload();
                } else {
                    alert(data.error || 'Failed to schedule appointment');
                    submitButton.disabled = false;
                    submitButton.innerHTML = 'Schedule Appointment';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while scheduling the appointment');
                submitButton.disabled = false;
                submitButton.innerHTML = 'Schedule Appointment';
            });

            return false;
        }

        function cancelAppointment(appointmentId) {
            if (confirm('Are you sure you want to cancel this appointment?')) {
                fetch('cancel_appointment.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        appointment_id: parseInt(appointmentId)
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Appointment cancelled successfully!');
                        window.location.reload();
                    } else {
                        alert(data.error || 'Failed to cancel appointment');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while cancelling the appointment');
                });
            }
        }
    </script>
</body>
</html> 