<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Check if user is logged in and is a donor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'donor') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

try {
    $pdo = getConnection();
    
    // Get donor information
    $stmt = $pdo->prepare("
        SELECT 
            d.donor_id,
            d.name,
            d.blood_group,
            d.age,
            d.gender,
            d.contact,
            d.address,
            u.email,
            (
                SELECT MAX(collection_date)
                FROM blood_units
                WHERE donor_id = d.donor_id
            ) as last_donation
        FROM donors d
        JOIN users u ON d.user_id = u.user_id
        WHERE d.user_id = ?
    ");
    
    $stmt->execute([$_SESSION['user_id']]);
    $donor = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$donor) {
        http_response_code(404);
        echo json_encode(['error' => 'Donor not found']);
        exit;
    }
    
    // Remove sensitive information
    unset($donor['user_id']);
    
    echo json_encode([
        'success' => true,
        'donor' => $donor
    ]);

} catch (PDOException $e) {
    error_log("Donor profile error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Database error occurred']);
} catch (Exception $e) {
    error_log("Donor profile error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'An unexpected error occurred']);
}
?> 