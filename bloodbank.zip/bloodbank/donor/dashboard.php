<?php
header('Content-Type: application/json');
require_once '../config/database.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'donor') {
    echo json_encode([
        'status' => 'error',
        'message' => 'Unauthorized access'
    ]);
    exit;
}

try {
    // Get donor profile
    $stmt = $pdo->prepare("
        SELECT d.*, u.username 
        FROM donors d 
        JOIN users u ON d.user_id = u.user_id 
        WHERE d.user_id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $profile = $stmt->fetch(PDO::FETCH_ASSOC);

    // Get upcoming appointments
    $stmt = $pdo->prepare("
        SELECT a.*, h.name as hospital_name 
        FROM appointments a 
        JOIN hospitals h ON a.hospital_id = h.hospital_id 
        WHERE a.donor_id = ? AND a.appointment_date >= CURDATE() 
        ORDER BY a.appointment_date, a.appointment_time
    ");
    $stmt->execute([$profile['donor_id']]);
    $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get donation history
    $stmt = $pdo->prepare("
        SELECT bu.*, h.name as hospital_name 
        FROM blood_units bu 
        JOIN hospitals h ON bu.hospital_id = h.hospital_id 
        WHERE bu.donor_id = ? 
        ORDER BY bu.donation_date DESC
    ");
    $stmt->execute([$profile['donor_id']]);
    $donation_history = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get available hospitals for scheduling
    $stmt = $pdo->prepare("
        SELECT hospital_id, name, city 
        FROM hospitals 
        WHERE status = 'active'
    ");
    $stmt->execute();
    $hospitals = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'status' => 'success',
        'data' => [
            'profile' => $profile,
            'appointments' => $appointments,
            'donation_history' => $donation_history,
            'hospitals' => $hospitals
        ]
    ]);
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?> 