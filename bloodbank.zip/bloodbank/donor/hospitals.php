<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Check if user is logged in and is a donor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'donor') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

try {
    $pdo = getConnection();
    
    // Get active hospitals
    $stmt = $pdo->prepare("
        SELECT 
            h.hospital_id,
            h.name,
            h.address,
            h.operating_hours
        FROM hospitals h
        WHERE h.status = 'active'
        ORDER BY h.name
    ");
    
    $stmt->execute();
    $hospitals = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'hospitals' => $hospitals
    ]);

} catch (PDOException $e) {
    error_log("Donor hospitals error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Database error occurred']);
} catch (Exception $e) {
    error_log("Donor hospitals error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'An unexpected error occurred']);
}
?> 