<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Check if user is logged in and is a donor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'donor') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (!isset($data['appointment_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Appointment ID is required']);
    exit;
}

try {
    $pdo = getConnection();
    
    // Start transaction
    $pdo->beginTransaction();
    
    // Get donor ID
    $stmt = $pdo->prepare("SELECT donor_id FROM donors WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $donor = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$donor) {
        throw new Exception('Donor not found');
    }
    
    // Verify appointment belongs to donor and is not already cancelled
    $stmt = $pdo->prepare("
        SELECT appointment_id, status, appointment_date
        FROM appointments
        WHERE appointment_id = ? 
        AND donor_id = ?
        AND status = 'scheduled'
    ");
    $stmt->execute([$data['appointment_id'], $donor['donor_id']]);
    $appointment = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$appointment) {
        throw new Exception('Appointment not found or cannot be cancelled');
    }
    
    // Check if appointment is in the future
    if (strtotime($appointment['appointment_date']) < strtotime('today')) {
        throw new Exception('Cannot cancel past appointments');
    }
    
    // Update appointment status
    $stmt = $pdo->prepare("
        UPDATE appointments 
        SET status = 'cancelled'
        WHERE appointment_id = ?
    ");
    $stmt->execute([$data['appointment_id']]);
    
    // Create notification for the donor
    $stmt = $pdo->prepare("
        INSERT INTO notifications (
            user_id,
            title,
            message,
            type,
            is_read,
            created_at
        ) VALUES (?, ?, ?, 'appointment', 0, NOW())
    ");
    
    $stmt->execute([
        $_SESSION['user_id'],
        'Appointment Cancelled',
        'Your blood donation appointment has been cancelled.'
    ]);
    
    // Commit transaction
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Appointment cancelled successfully'
    ]);

} catch (Exception $e) {
    // Rollback transaction on error
    if (isset($pdo)) {
        $pdo->rollBack();
    }
    
    error_log("Appointment cancellation error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?> 