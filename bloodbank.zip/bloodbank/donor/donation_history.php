<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Check if user is logged in and is a donor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'donor') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

try {
    $pdo = getConnection();
    
    // Get donor ID
    $stmt = $pdo->prepare("SELECT donor_id FROM donors WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $donor = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$donor) {
        http_response_code(404);
        echo json_encode(['error' => 'Donor not found']);
        exit;
    }
    
    // Get donation history
    $stmt = $pdo->prepare("
        SELECT b.*, h.name as hospital_name
        FROM blood_units b
        JOIN hospitals h ON b.hospital_id = h.hospital_id
        WHERE b.donor_id = ?
        ORDER BY b.donation_date DESC
    ");
    
    $stmt->execute([$donor['donor_id']]);
    $donations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'donations' => $donations
    ]);

} catch (PDOException $e) {
    error_log("Donation history error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Database error occurred']);
} catch (Exception $e) {
    error_log("Donation history error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'An unexpected error occurred']);
}
?> 