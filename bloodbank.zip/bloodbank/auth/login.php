<?php
session_start();
require_once '../config/database.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/login_errors.log');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    error_log("Invalid JSON data received");
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON data']);
    exit;
}

// Log received data (excluding password)
$logData = $data;
unset($logData['password']);
error_log("Login attempt: " . print_r($logData, true));

// Validate required fields
if (empty($data['username']) || empty($data['password']) || empty($data['role'])) {
    error_log("Missing required fields");
    http_response_code(400);
    echo json_encode(['error' => 'Username, password, and role are required']);
    exit;
}

try {
    $pdo = getConnection();
    
    // Fetch user details including entity_id and full_name based on role
    $stmt = $pdo->prepare("
        SELECT u.*, 
            CASE 
                WHEN u.role = 'donor' THEN d.donor_id
                WHEN u.role = 'recipient' THEN r.recipient_id
                WHEN u.role = 'hospital' THEN h.hospital_id
                ELSE NULL
            END as entity_id,
            CASE 
                WHEN u.role = 'donor' THEN d.name
                WHEN u.role = 'recipient' THEN r.name
                WHEN u.role = 'hospital' THEN h.name
                WHEN u.role = 'admin' THEN u.full_name
                ELSE NULL
            END as full_name,
            CASE 
                WHEN u.role = 'hospital' THEN h.status
                ELSE NULL
            END as hospital_status
        FROM users u
        LEFT JOIN donors d ON u.user_id = d.user_id
        LEFT JOIN recipients r ON u.user_id = r.user_id
        LEFT JOIN hospitals h ON u.user_id = h.user_id
        WHERE u.username = ? AND u.role = ?
    ");
    
    $stmt->execute([$data['username'], $data['role']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        error_log("User not found with username: {$data['username']} and role: {$data['role']}");
        http_response_code(401);
        echo json_encode(['error' => 'Invalid username, password, or role']);
        exit;
    }

    error_log("User found: " . print_r($user, true));

    // Check if user is active
    if ($user['status'] !== 'active') {
        error_log("User is not active. Status: {$user['status']}");
        http_response_code(401);
        echo json_encode(['error' => 'Your account is not active. Please wait for admin approval.']);
        exit;
    }

    // Check if hospital status is active (for hospital users)
    if ($user['role'] === 'hospital' && $user['hospital_status'] !== 'active') {
        error_log("Hospital is not active. Status: {$user['hospital_status']}");
        http_response_code(401);
        echo json_encode(['error' => 'Your hospital account is not active. Please wait for admin approval.']);
        exit;
    }

    // Verify password
    if (!password_verify($data['password'], $user['password'])) {
        error_log("Password verification failed for user: {$user['username']}");
        http_response_code(401);
        echo json_encode(['error' => 'Invalid password']);
        exit;
    }

    error_log("Login successful for user: {$user['username']}");

    // Update last login
    $updateStmt = $pdo->prepare("UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE user_id = ?");
    $updateStmt->execute([$user['user_id']]);

    // Set session variables
    $_SESSION['user_id'] = $user['user_id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role'];
    // Set entity_id and full_name conditionally for admin
    $_SESSION['entity_id'] = isset($user['entity_id']) ? $user['entity_id'] : null;
    $_SESSION['full_name'] = isset($user['full_name']) ? $user['full_name'] : null;

    // Get unread notifications count
    $notifStmt = $pdo->prepare("
        SELECT COUNT(*) as unread_count 
        FROM notifications 
        WHERE user_id = ? AND is_read = FALSE
    ");
    $notifStmt->execute([$user['user_id']]);
    $notifications = $notifStmt->fetch(PDO::FETCH_ASSOC);

    // Prepare response data
    $response = [
        'success' => true,
        'user' => [
            'user_id' => $user['user_id'],
            'username' => $user['username'],
            'role' => $user['role'],
            'email' => $user['email'],
            'full_name' => isset($user['full_name']) ? $user['full_name'] : null, // Handle full_name conditionally
            'entity_id' => isset($user['entity_id']) ? $user['entity_id'] : null, // Handle entity_id conditionally
            'unread_notifications' => $notifications['unread_count']
        ]
    ];

    echo json_encode($response);

} catch (PDOException $e) {
    error_log("Database error during login: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Database error occurred: ' . $e->getMessage()]);
} catch (Exception $e) {
    error_log("Unexpected error during login: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'An unexpected error occurred: ' . $e->getMessage()]);
}
?> 