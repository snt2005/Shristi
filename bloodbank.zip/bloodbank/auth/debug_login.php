<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

$debug_info = [
    'received_data' => $data,
    'database_connection' => null,
    'database_name' => null,
    'tables_exist' => [],
    'user_query_result' => null,
    'password_verification' => null,
    'error' => null
];

try {
    // Test database connection
    $pdo = getConnection();
    $debug_info['database_connection'] = 'Connected successfully';
    
    // Get database name
    $stmt = $pdo->query("SELECT DATABASE()");
    $debug_info['database_name'] = $stmt->fetchColumn();
    
    // Check if tables exist
    $tables = ['users', 'donors', 'recipients', 'hospitals', 'notifications'];
    foreach ($tables as $table) {
        $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
        $debug_info['tables_exist'][$table] = $stmt->rowCount() > 0;
    }
    
    if ($data) {
        // Check if user exists
        $stmt = $pdo->prepare("
            SELECT u.*, 
                CASE 
                    WHEN u.role = 'donor' THEN d.donor_id
                    WHEN u.role = 'recipient' THEN r.recipient_id
                    WHEN u.role = 'hospital' THEN h.hospital_id
                    ELSE NULL
                END as entity_id
            FROM users u
            LEFT JOIN donors d ON u.user_id = d.user_id
            LEFT JOIN recipients r ON u.user_id = r.user_id
            LEFT JOIN hospitals h ON u.user_id = h.user_id
            WHERE u.username = ? AND u.role = ?
        ");
        
        $stmt->execute([$data['username'], $data['role']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $debug_info['user_query_result'] = $user;
        
        if ($user) {
            $debug_info['password_verification'] = password_verify($data['password'], $user['password']);
            $debug_info['stored_password_hash'] = $user['password'];
            $debug_info['provided_password'] = $data['password'];
        } else {
            // Check if username exists with different role
            $stmt = $pdo->prepare("SELECT role FROM users WHERE username = ?");
            $stmt->execute([$data['username']]);
            $existing_role = $stmt->fetchColumn();
            if ($existing_role) {
                $debug_info['username_exists_with_role'] = $existing_role;
            }
        }
    }
} catch (PDOException $e) {
    $debug_info['error'] = $e->getMessage();
    $debug_info['error_code'] = $e->getCode();
    $debug_info['error_trace'] = $e->getTraceAsString();
}

echo json_encode($debug_info, JSON_PRETTY_PRINT);
?> 