<?php
session_start();
require_once '../config/database.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0); // Disable display of errors
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/registration_errors.log');

header('Content-Type: application/json');

try {
    // Get JSON data
    $jsonData = file_get_contents('php://input');
    if (!$jsonData) {
        throw new Exception('No data received');
    }

    $data = json_decode($jsonData, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON data: ' . json_last_error_msg());
    }

    // Validate required fields
    $required_fields = ['username', 'email', 'password', 'role'];
    foreach ($required_fields as $field) {
        if (!isset($data[$field]) || empty($data[$field])) {
            throw new Exception(ucfirst(str_replace('_', ' ', $field)) . ' is required');
        }
    }

    $pdo = getConnection();
    
    // Start transaction
    $pdo->beginTransaction();
    
    // Check if username or email already exists
    $stmt = $pdo->prepare("SELECT user_id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$data['username'], $data['email']]);
    if ($stmt->fetch()) {
        throw new Exception('Username or email already exists');
    }
    
    // Create user account
    $stmt = $pdo->prepare("
        INSERT INTO users (username, email, password, role, status, created_at) 
        VALUES (?, ?, ?, ?, 'pending', CURRENT_TIMESTAMP)
    ");
    
    $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
    $stmt->execute([
        $data['username'],
        $data['email'],
        $hashedPassword,
        $data['role']
    ]);
    
    $userId = $pdo->lastInsertId();
    if (!$userId) {
        throw new Exception('Failed to create user account');
    }
    
    // Create notification for admin
    $stmt = $pdo->prepare("
        INSERT INTO notifications (
            user_id,
            title,
            message,
            type,
            is_read,
            created_at
        ) VALUES (
            (SELECT user_id FROM users WHERE role = 'admin' LIMIT 1),
            'New User Registration',
            'A new user has registered and is pending approval.',
            'registration',
            0,
            CURRENT_TIMESTAMP
        )
    ");
    $stmt->execute();
    
    // Commit transaction
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Registration successful! Please wait for admin approval.'
    ]);

} catch (PDOException $e) {
    // Rollback transaction on error
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    error_log("Database error during registration: " . $e->getMessage());
    error_log("SQL State: " . $e->getCode());
    error_log("Stack trace: " . $e->getTraceAsString());
    
    echo json_encode([
        'error' => 'Database error occurred',
        'details' => $e->getMessage()
    ]);
} catch (Exception $e) {
    // Rollback transaction on error
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    error_log("Registration error: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());
    
    echo json_encode([
        'error' => $e->getMessage()
    ]);
}
?> 