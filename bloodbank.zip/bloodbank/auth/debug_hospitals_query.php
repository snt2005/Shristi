<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database configuration
require_once '../config/database.php';

try {
    $pdo = getConnection();
    echo "<h2>Debugging Hospitals Query</h2>";

    // Get all hospitals with their user information (Exact query from admin/hospitals.php)
    $stmt = $pdo->prepare("
        SELECT h.*, u.username, u.email, u.status, u.created_at
        FROM hospitals h
        JOIN users u ON h.user_id = u.user_id
        ORDER BY u.created_at DESC
    ");
    $stmt->execute();
    $hospitals = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo "<h3>Query Results:</h3>";
    if (!empty($hospitals)) {
        echo "<pre>";
        print_r($hospitals);
        echo "</pre>
";
    } else {
        echo "<p>No hospitals found by the query.</p>";
    }

} catch (PDOException $e) {
    echo "<p style='color: red;'>Database Error: " . $e->getMessage() . "</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?> 