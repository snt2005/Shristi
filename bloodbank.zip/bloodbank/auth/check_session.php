<?php
session_start();

function checkSession() {
    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Not authenticated']);
        exit();
    }

    // Check session timeout
    if (isset($_SESSION['last_activity']) && isset($_SESSION['expire_time'])) {
        $inactive = time() - $_SESSION['last_activity'];
        if ($inactive >= $_SESSION['expire_time']) {
            session_unset();
            session_destroy();
            header('Content-Type: application/json');
            echo json_encode(['status' => 'error', 'message' => 'Session expired']);
            exit();
        }
        $_SESSION['last_activity'] = time();
    }

    return [
        'user_id' => $_SESSION['user_id'],
        'role' => $_SESSION['role'],
        'username' => $_SESSION['username']
    ];
}

// Function to check if user has required role
function checkRole($requiredRole) {
    $user = checkSession();
    if ($user['role'] !== $requiredRole) {
        header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
        exit();
    }
    return $user;
}
?> 