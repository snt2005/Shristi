<?php
require_once '../config/database.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get username from query parameter
$username = isset($_GET['username']) ? $_GET['username'] : '';

if (empty($username)) {
    die("Please provide a username as a query parameter (e.g., ?username=charan)");
}

try {
    $pdo = getConnection();
    
    echo "<h2>Checking user and hospital data for: " . htmlspecialchars($username) . "</h2>";

    // Check users table
    $userStmt = $pdo->prepare("SELECT user_id, username, role, status, created_at FROM users WHERE username = ?");
    $userStmt->execute([$username]);
    $user = $userStmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        echo "<h3>User Table Entry:</h3>";
        echo "<pre>";
        print_r($user);
        echo "</pre>";
        
        $userId = $user['user_id'];
        
        // If user is a hospital, check hospitals table
        if ($user['role'] === 'hospital') {
            $hospitalStmt = $pdo->prepare("SELECT hospital_id, user_id, name, status FROM hospitals WHERE user_id = ?");
            $hospitalStmt->execute([$userId]);
            $hospital = $hospitalStmt->fetch(PDO::FETCH_ASSOC);

            echo "<h3>Hospitals Table Entry (linked by user_id " . $userId . "):</h3>";
            if ($hospital) {
                echo "<pre>";
                print_r($hospital);
                echo "</pre>";
            } else {
                echo "<p style='color: red;'>No matching entry found in hospitals table for user_id " . $userId . "!</p>";
            }
        } else {
            echo "<p>User is not a hospital role.</p>";
        }
        
    } else {
        echo "<p style='color: red;'>User with username '" . htmlspecialchars($username) . "' not found in users table!</p>";
    }
    
} catch (Exception $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?> 