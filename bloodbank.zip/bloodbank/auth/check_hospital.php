<?php
require_once '../config/database.php';

try {
    $pdo = getConnection();
    
    // Get all pending hospitals
    $stmt = $pdo->prepare("
        SELECT u.*, h.hospital_id, h.status as hospital_status 
        FROM users u 
        JOIN hospitals h ON u.user_id = h.user_id 
        WHERE u.role = 'hospital' AND (u.status = 'pending' OR h.status = 'pending')
    ");
    $stmt->execute();
    $hospitals = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h2>Hospital Status Check</h2>";
    
    if (empty($hospitals)) {
        echo "No pending hospitals found.";
    } else {
        echo "<table border='1'>";
        echo "<tr><th>Username</th><th>Hospital Name</th><th>User Status</th><th>Hospital Status</th><th>Action</th></tr>";
        
        foreach ($hospitals as $hospital) {
            echo "<tr>";
            echo "<td>{$hospital['username']}</td>";
            echo "<td>{$hospital['name']}</td>";
            echo "<td>{$hospital['status']}</td>";
            echo "<td>{$hospital['hospital_status']}</td>";
            echo "<td>";
            
            // Update both user and hospital status to active
            $updateStmt = $pdo->prepare("
                UPDATE users u 
                JOIN hospitals h ON u.user_id = h.user_id 
                SET u.status = 'active', h.status = 'active' 
                WHERE u.user_id = ?
            ");
            $updateStmt->execute([$hospital['user_id']]);
            
            echo "Approved</td>";
            echo "</tr>";
        }
        
        echo "</table>";
        echo "<p>All pending hospitals have been approved.</p>";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?> 