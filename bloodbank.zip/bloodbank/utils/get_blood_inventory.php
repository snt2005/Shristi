<?php
require_once '../config/database.php';

header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT b.*, h.name as hospital_name 
                         FROM blood_units b 
                         JOIN hospitals h ON b.hospital_id = h.hospital_id 
                         WHERE b.status = 'available'");
    $inventory = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['status' => 'success', 'data' => $inventory]);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?> 