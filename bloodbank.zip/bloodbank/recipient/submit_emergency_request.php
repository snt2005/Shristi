<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is a recipient
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'recipient') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Get JSON data
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Validate input
if (!$data || !isset($data['blood_group']) || !isset($data['units_needed']) || 
    !isset($data['urgency']) || !isset($data['reason'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

try {
    $pdo = getConnection();
    $pdo->beginTransaction();

    // Get recipient ID
    $stmt = $pdo->prepare("SELECT recipient_id FROM recipients WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $recipient = $stmt->fetch();

    if (!$recipient) {
        throw new Exception('Recipient not found');
    }

    // Create emergency request
    $stmt = $pdo->prepare("
        INSERT INTO emergency_requests (
            recipient_id, blood_group, units_needed, urgency, reason, status, created_at
        ) VALUES (?, ?, ?, ?, ?, 'pending', NOW())
    ");
    $stmt->execute([
        $recipient['recipient_id'],
        $data['blood_group'],
        $data['units_needed'],
        $data['urgency'],
        $data['reason']
    ]);

    $requestId = $pdo->lastInsertId();

    // Get all hospitals with matching blood units
    $stmt = $pdo->prepare("
        SELECT DISTINCT h.hospital_id, h.name, h.email
        FROM hospitals h
        JOIN blood_units bu ON h.hospital_id = bu.hospital_id
        WHERE bu.blood_group = ? AND bu.status = 'available'
        AND h.status = 'active'
    ");
    $stmt->execute([$data['blood_group']]);
    $hospitals = $stmt->fetchAll();

    // Create notifications for hospitals
    foreach ($hospitals as $hospital) {
        $stmt = $pdo->prepare("
            INSERT INTO notifications (
                user_id, type, message, reference_id, created_at
            ) VALUES (?, 'emergency_request', ?, ?, NOW())
        ");
        $stmt->execute([
            $hospital['hospital_id'],
            "Emergency blood request for {$data['units_needed']} units of {$data['blood_group']} blood. Urgency: {$data['urgency']}",
            $requestId
        ]);
    }

    $pdo->commit();
    echo json_encode(['success' => true, 'request_id' => $requestId]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
} 