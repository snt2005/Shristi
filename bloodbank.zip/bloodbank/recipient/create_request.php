<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Check if user is logged in and is a recipient
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'recipient') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
$required_fields = ['blood_group', 'component_type', 'units_required', 'required_date', 'hospital_id', 'priority', 'reason'];
foreach ($required_fields as $field) {
    if (!isset($data[$field]) || empty($data[$field])) {
        http_response_code(400);
        echo json_encode(['error' => ucfirst(str_replace('_', ' ', $field)) . ' is required']);
        exit;
    }
}

try {
    $pdo = getConnection();
    
    // Start transaction
    $pdo->beginTransaction();
    
    // Get recipient ID
    $stmt = $pdo->prepare("SELECT recipient_id FROM recipients WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $recipient = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$recipient) {
        throw new Exception('Recipient not found');
    }
    
    // Validate hospital
    $stmt = $pdo->prepare("SELECT hospital_id FROM hospitals WHERE hospital_id = ? AND status = 'active'");
    $stmt->execute([$data['hospital_id']]);
    if (!$stmt->fetch()) {
        throw new Exception('Invalid or inactive hospital');
    }
    
    // Create blood request
    $stmt = $pdo->prepare("
        INSERT INTO blood_requests (
            recipient_id,
            hospital_id,
            blood_group,
            component_type,
            units_required,
            required_date,
            priority,
            reason,
            status,
            request_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', CURRENT_TIMESTAMP)
    ");
    
    $stmt->execute([
        $recipient['recipient_id'],
        $data['hospital_id'],
        $data['blood_group'],
        $data['component_type'],
        $data['units_required'],
        $data['required_date'],
        $data['priority'],
        $data['reason']
    ]);
    
    $request_id = $pdo->lastInsertId();
    
    // Create notification for recipient
    $stmt = $pdo->prepare("
        INSERT INTO notifications (
            user_id,
            title,
            message,
            type,
            is_read,
            created_at
        ) VALUES (?, 'Blood Request Submitted', 'Your blood request has been submitted successfully.', 'request', 0, CURRENT_TIMESTAMP)
    ");
    $stmt->execute([$_SESSION['user_id']]);
    
    // Create notifications for hospitals
    $stmt = $pdo->prepare("
        INSERT INTO notifications (
            user_id,
            title,
            message,
            type,
            is_read,
            created_at
        ) VALUES (
            (SELECT user_id FROM hospitals WHERE hospital_id = ?),
            'New Blood Request',
            'A new blood request has been submitted.',
            'request',
            0,
            CURRENT_TIMESTAMP
        )
    ");
    $stmt->execute([$data['hospital_id']]);
    
    // Commit transaction
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Blood request created successfully',
        'request_id' => $request_id
    ]);

} catch (Exception $e) {
    // Rollback transaction on error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    error_log("Create blood request error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?> 