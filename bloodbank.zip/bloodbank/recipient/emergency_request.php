<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is a recipient
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'recipient') {
    header('Location: ../login.html');
    exit;
}

$pdo = getConnection();

// Get recipient information
$stmt = $pdo->prepare("
    SELECT r.*, u.username, u.email 
    FROM recipients r 
    JOIN users u ON r.user_id = u.user_id 
    WHERE r.user_id = ?
");
$stmt->execute([$_SESSION['user_id']]);
$recipient = $stmt->fetch();

// Get available blood units from all hospitals
$stmt = $pdo->prepare("
    SELECT bu.*, h.name as hospital_name, h.address, h.city, h.contact
    FROM blood_units bu
    JOIN hospitals h ON bu.hospital_id = h.hospital_id
    WHERE bu.status = 'available'
    ORDER BY h.name, bu.blood_group
");
$stmt->execute();
$availableUnits = $stmt->fetchAll();

// Group blood units by hospital
$hospitalUnits = [];
foreach ($availableUnits as $unit) {
    $hospitalId = $unit['hospital_id'];
    if (!isset($hospitalUnits[$hospitalId])) {
        $hospitalUnits[$hospitalId] = [
            'name' => $unit['hospital_name'],
            'address' => $unit['address'],
            'city' => $unit['city'],
            'contact' => $unit['contact'],
            'units' => []
        ];
    }
    $hospitalUnits[$hospitalId]['units'][] = $unit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emergency Blood Request - Blood Bank Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" rel="stylesheet">
    <link href="../style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Emergency Blood Request</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../recipient_dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="emergency_request.php">Emergency Request</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="request_history.php">Request History</a>
                    </li>
                </ul>
                <div class="d-flex">
                    <a href="../auth/logout.php" class="btn btn-light">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <!-- Emergency Request Form -->
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Make Emergency Request</h5>
                    </div>
                    <div class="card-body">
                        <form id="emergencyRequestForm" onsubmit="return submitEmergencyRequest(event)">
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label for="blood_group" class="form-label">Required Blood Group</label>
                                    <select class="form-select" id="blood_group" name="blood_group" required>
                                        <option value="">Select Blood Group</option>
                                        <option value="A+">A+</option>
                                        <option value="A-">A-</option>
                                        <option value="B+">B+</option>
                                        <option value="B-">B-</option>
                                        <option value="AB+">AB+</option>
                                        <option value="AB-">AB-</option>
                                        <option value="O+">O+</option>
                                        <option value="O-">O-</option>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="units_needed" class="form-label">Units Needed</label>
                                    <input type="number" class="form-control" id="units_needed" name="units_needed" min="1" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="urgency" class="form-label">Urgency Level</label>
                                    <select class="form-select" id="urgency" name="urgency" required>
                                        <option value="">Select Urgency</option>
                                        <option value="critical">Critical (Within 1 hour)</option>
                                        <option value="urgent">Urgent (Within 4 hours)</option>
                                        <option value="normal">Normal (Within 24 hours)</option>
                                    </select>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="reason" class="form-label">Reason for Request</label>
                                <textarea class="form-control" id="reason" name="reason" rows="3" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Submit Emergency Request</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Available Blood Units -->
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Available Blood Units in Hospitals</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($hospitalUnits)): ?>
                            <p class="text-center text-muted">No blood units available at the moment</p>
                        <?php else: ?>
                            <?php foreach ($hospitalUnits as $hospitalId => $hospital): ?>
                                <div class="card mb-3">
                                    <div class="card-header">
                                        <h6 class="mb-0"><?php echo htmlspecialchars($hospital['name']); ?></h6>
                                        <small class="text-muted">
                                            <?php echo htmlspecialchars($hospital['address']); ?>, 
                                            <?php echo htmlspecialchars($hospital['city']); ?> | 
                                            Contact: <?php echo htmlspecialchars($hospital['contact']); ?>
                                        </small>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <?php
                                            $bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
                                            $groupCounts = [];
                                            foreach ($hospital['units'] as $unit) {
                                                $groupCounts[$unit['blood_group']] = ($groupCounts[$unit['blood_group']] ?? 0) + 1;
                                            }
                                            foreach ($bloodGroups as $group):
                                                $count = $groupCounts[$group] ?? 0;
                                            ?>
                                                <div class="col-md-3 mb-2">
                                                    <div class="card bg-light">
                                                        <div class="card-body text-center">
                                                            <h6 class="mb-0"><?php echo $group; ?></h6>
                                                            <p class="mb-0"><?php echo $count; ?> units available</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function submitEmergencyRequest(event) {
            event.preventDefault();
            
            const formData = {
                blood_group: document.getElementById('blood_group').value,
                units_needed: document.getElementById('units_needed').value,
                urgency: document.getElementById('urgency').value,
                reason: document.getElementById('reason').value
            };

            fetch('submit_emergency_request.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Emergency request submitted successfully');
                    location.reload();
                } else {
                    alert(data.error || 'Failed to submit emergency request');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while submitting the request');
            });

            return false;
        }
    </script>
</body>
</html> 