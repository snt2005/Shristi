<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is a recipient
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'recipient') {
    header('Location: ../login.html');
    exit;
}

try {
    $pdo = getConnection();
    
    // Get recipient information
    $stmt = $pdo->prepare("
        SELECT r.*, u.email, u.username
        FROM recipients r
        JOIN users u ON r.user_id = u.user_id
        WHERE r.user_id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $recipient = $stmt->fetch(PDO::FETCH_ASSOC);

    // Get active hospitals with their available blood inventory counts
    $stmt = $pdo->prepare("
        SELECT 
            h.hospital_id,
            h.name as hospital_name,
            h.address,
            h.city,
            h.contact,
            hic.blood_group,
            hic.component_type,
            hic.available_count
        FROM hospitals h
        JOIN hospital_inventory_counts hic ON h.hospital_id = hic.hospital_id
        WHERE h.status = 'active' AND hic.available_count > 0
        ORDER BY h.name, hic.blood_group, hic.component_type
    ");
    $stmt->execute();
    $hospitalInventory = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Group inventory by hospital
    $hospitalsWithInventory = [];
    foreach ($hospitalInventory as $item) {
        $hospitalId = $item['hospital_id'];
        if (!isset($hospitalsWithInventory[$hospitalId])) {
            $hospitalsWithInventory[$hospitalId] = [
                'name' => $item['hospital_name'],
                'address' => $item['address'],
                'city' => $item['city'],
                'contact' => $item['contact'],
                'inventory' => []
            ];
        }
        // Group inventory by blood group within the hospital
        if (!isset($hospitalsWithInventory[$hospitalId]['inventory'][$item['blood_group']])) {
             $hospitalsWithInventory[$hospitalId]['inventory'][$item['blood_group']] = [];
        }
        $hospitalsWithInventory[$hospitalId]['inventory'][$item['blood_group']][] = [
            'component_type' => $item['component_type'],
            'available_count' => $item['available_count']
        ];
    }

} catch (PDOException $e) {
    error_log("Emergency request error: " . $e->getMessage());
    $error = "An error occurred while loading available inventory.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emergency Blood Request - Blood Bank Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <link href="../style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Blood Bank Management System</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../recipient_dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="requests.php">Blood Requests</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="history.php">Request History</a>
                    </li>
                </ul>
                <div class="d-flex">
                    <a href="../auth/logout.php" class="btn btn-light">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card border-danger">
                    <div class="card-header bg-danger text-white">
                        <h5 class="card-title mb-0">Available Blood Inventory in Hospitals</h5>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-warning mb-4">
                            <i class="bi bi-exclamation-triangle-fill"></i>
                            <strong>Important:</strong> Below is the list of hospitals with available blood inventory counts based on their last update. 
                            Contact the hospital directly for emergency requests.
                        </div>

                        <?php if (empty($hospitalsWithInventory)): ?>
                            <p class="text-center">No hospitals with available blood inventory found at this time.</p>
                        <?php else: ?>
                            <?php foreach ($hospitalsWithInventory as $hospitalId => $hospital): ?>
                                <div class="card mb-3">
                                    <div class="card-header">
                                        <h6><?php echo htmlspecialchars($hospital['name']); ?> (<?php echo htmlspecialchars($hospital['city']); ?>)</h6>
                                    </div>
                                    <div class="card-body">
                                        <p><b>Address:</b> <?php echo htmlspecialchars($hospital['address']); ?></p>
                                        <p><b>Contact:</b> <?php echo htmlspecialchars($hospital['contact']); ?></p>
                                        <h6>Available Inventory:</h6>
                                        <ul>
                                            <?php foreach ($hospital['inventory'] as $bloodGroup => $componentTypes): ?>
                                                <li><b><?php echo htmlspecialchars($bloodGroup); ?>:</b>
                                                    <ul>
                                                        <?php foreach ($componentTypes as $item): ?>
                                                            <li>
                                                                <?php echo htmlspecialchars(ucfirst($item['component_type'])); ?>: <?php echo htmlspecialchars($item['available_count']); ?> units
                                                                <?php if ($item['available_count'] > 0): ?>
                                                                    <button class="btn btn-sm btn-danger request-btn" 
                                                                            data-hospital-id="<?php echo $hospitalId; ?>" 
                                                                            data-blood-group="<?php echo htmlspecialchars($bloodGroup); ?>" 
                                                                            data-component-type="<?php echo htmlspecialchars($item['component_type']); ?>">
                                                                        Request
                                                                    </button>
                                                                <?php endif; ?>
                                                            </li>
                                                        <?php endforeach; ?>
                                                    </ul>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                         <!-- Optionally add a button to link to a request form for this hospital -->
                                        <!-- <a href="make_request.php?hospital_id=<?php echo $hospitalId; ?>" class="btn btn-sm btn-primary">Request from this Hospital</a> -->
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>

                         <!-- Removed the direct emergency request form -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Request Modal -->
    <div class="modal fade" id="requestModal" tabindex="-1" aria-labelledby="requestModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="requestModalLabel">Request Blood</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form id="bloodRequestForm">
                <input type="hidden" id="modalHospitalId">
                <input type="hidden" id="modalBloodGroup">
                <input type="hidden" id="modalComponentType">
                
                <div class="mb-3">
                    <label for="modalBloodInfo" class="form-label">Blood Type Requested</label>
                    <input type="text" class="form-control" id="modalBloodInfo" readonly>
                </div>

                <div class="mb-3">
                    <label for="modalUnitsNeeded" class="form-label">Units Needed</label>
                    <input type="number" class="form-control" id="modalUnitsNeeded" min="1" required>
                </div>

                 <div class="mb-3">
                    <label for="modalRequiredDate" class="form-label">Required By Date</label>
                    <input type="date" class="form-control" id="modalRequiredDate" required>
                </div>

                <div class="mb-3">
                    <label for="modalReason" class="form-label">Reason for Request</label>
                    <textarea class="form-control" id="modalReason" rows="3" required></textarea>
                </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-danger" form="bloodRequestForm">Submit Request</button>
          </div>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Set minimum date for required date to today
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('modalRequiredDate').min = today;

        document.querySelectorAll('.request-btn').forEach(button => {
            button.addEventListener('click', function() {
                const hospitalId = this.dataset.hospitalId;
                const bloodGroup = this.dataset.bloodGroup;
                const componentType = this.dataset.componentType;

                // Populate modal fields
                document.getElementById('modalHospitalId').value = hospitalId;
                document.getElementById('modalBloodGroup').value = bloodGroup;
                document.getElementById('modalComponentType').value = componentType;
                document.getElementById('modalBloodInfo').value = `${bloodGroup} - ${componentType}`;
                document.getElementById('modalUnitsNeeded').value = ''; // Clear previous value
                document.getElementById('modalReason').value = ''; // Clear previous value
                 document.getElementById('modalRequiredDate').value = today; // Set default to today

                // Show the modal
                const requestModal = new bootstrap.Modal(document.getElementById('requestModal'));
                requestModal.show();
            });
        });

        document.getElementById('bloodRequestForm').addEventListener('submit', function(event) {
            event.preventDefault();

            const hospitalId = document.getElementById('modalHospitalId').value;
            const bloodGroup = document.getElementById('modalBloodGroup').value;
            const componentType = document.getElementById('modalComponentType').value;
            const unitsNeeded = document.getElementById('modalUnitsNeeded').value;
            const requiredDate = document.getElementById('modalRequiredDate').value;
            const reason = document.getElementById('modalReason').value;

            const requestData = {
                hospital_id: hospitalId,
                blood_group: bloodGroup,
                component_type: componentType,
                units_required: parseInt(unitsNeeded, 10),
                required_date: requiredDate,
                priority: 'emergency', // Mark as emergency
                reason: reason
            };

            // Send requestData to the backend script (create_request.php)
            fetch('create_request.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(requestData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Emergency request submitted successfully!');
                    // Hide modal and potentially reload page or update UI
                    const requestModal = bootstrap.Modal.getInstance(document.getElementById('requestModal'));
                    requestModal.hide();
                    // Optionally, reload the page to reflect changes or show a success message
                     // location.reload(); 
                } else {
                    alert(data.error || 'Failed to submit emergency request.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while submitting the request.');
            });
        });

    </script>
</body>
</html> 