<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

// Check if user is logged in and is a hospital
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'hospital') {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized access']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (!isset($data['request_id']) || empty($data['status'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Request ID and status are required']);
    exit;
}

$requestId = $data['request_id'];
$status = $data['status'];

// Validate status value
$valid_statuses = ['approved', 'rejected'];
if (!in_array($status, $valid_statuses)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid status value']);
    exit;
}

try {
    $pdo = getConnection();
    
    // Get hospital ID from the session user
    $stmt = $pdo->prepare("SELECT hospital_id FROM hospitals WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $hospital = $stmt->fetch();
    
    if (!$hospital) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Hospital not found']);
        exit;
    }
    
    $hospital_id = $hospital['hospital_id'];
    
    // Verify that the blood request exists and belongs to this hospital and is pending
    $stmt = $pdo->prepare("
        SELECT COUNT(*) FROM blood_requests 
        WHERE request_id = ? AND hospital_id = ? AND status = 'pending'
    ");
    $stmt->execute([$requestId, $hospital_id]);
    
    if ($stmt->fetchColumn() === 0) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Blood request not found, does not belong to this hospital, or is not pending.']);
        exit;
    }

    // Update the blood request status
    $stmt = $pdo->prepare("UPDATE blood_requests SET status = ? WHERE request_id = ?");
    $stmt->execute([$status, $requestId]);

    echo json_encode(['success' => true, 'message' => 'Blood request status updated successfully']);

} catch (Exception $e) {
    error_log("Update request status error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?> 