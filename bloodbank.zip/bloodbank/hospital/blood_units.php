<?php
session_start();
require_once '../config/database.php';

// Check if user is logged in and is a hospital
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'hospital') {
    header('Location: ../login.html');
    exit;
}

$pdo = getConnection();

// Get hospital ID and name
$stmt = $pdo->prepare("SELECT hospital_id, name FROM hospitals WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$hospital = $stmt->fetch();
if (!$hospital) {
    die('Hospital not found.');
}

// Fetch current inventory counts from the hospital_inventory_counts table
$stmt = $pdo->prepare("
    SELECT blood_group, component_type, available_count
    FROM hospital_inventory_counts
    WHERE hospital_id = ?
    ORDER BY blood_group, component_type
");
$stmt->execute([$hospital['hospital_id']]);
$currentInventoryCounts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Reorganize counts for easier display (e.g., $counts['A+']['Whole'] = 5)
$inventoryCounts = [];
foreach ($currentInventoryCounts as $item) {
    $inventoryCounts[$item['blood_group']][$item['component_type']] = $item['available_count'];
}

$bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
$componentTypes = ['Whole', 'RBC', 'Plasma', 'Platelets'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Inventory - <?php echo htmlspecialchars($hospital['name']); ?> | Blood Bank</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="../hospital_dashboard.php">Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="blood_units.php">Manage Inventory</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="requests.php">Blood Requests</a>
                    </li>
                </ul>
                <div class="d-flex align-items-center">
                    <div class="dropdown">
                        <button class="btn btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($hospital['name']); ?>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../auth/logout.php">Logout</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Manage Blood Inventory Counts</h5>
            </div>
            <div class="card-body">
                <form id="updateInventoryForm">
                    <?php foreach ($bloodGroups as $bloodGroup): ?>
                        <h6><?php echo htmlspecialchars($bloodGroup); ?></h6>
                        <div class="row mb-3">
                            <?php foreach ($componentTypes as $componentType): ?>
                                <div class="col-md-3 col-sm-6">
                                    <label for="<?php echo $bloodGroup . '_' . $componentType; ?>" class="form-label">Available <?php echo htmlspecialchars(ucfirst($componentType)); ?></label>
                                    <input type="number" class="form-control" id="<?php echo $bloodGroup . '_' . $componentType; ?>" name="counts[<?php echo $bloodGroup; ?>][<?php echo $componentType; ?>]" 
                                           value="<?php echo $inventoryCounts[$bloodGroup][$componentType] ?? 0; ?>" min="0" required>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <hr>
                    <?php endforeach; ?>
                    <button type="submit" class="btn btn-primary">Update Inventory</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('updateInventoryForm').addEventListener('submit', function(event) {
            event.preventDefault();

            const formData = new FormData(event.target);
            const counts = {};

            for (const [key, value] of formData.entries()) {
                // Extract blood group and component type from the name attribute
                const regex = /counts\[(.+)\]\[(.+)\]/;
                const match = key.match(regex);
                if (match && match[1] && match[2]) {
                    const bloodGroup = match[1];
                    const componentType = match[2];
                    if (!counts[bloodGroup]) {
                        counts[bloodGroup] = {};
                    }
                    counts[bloodGroup][componentType] = parseInt(value, 10) || 0; // Ensure integer
                }
            }

            // Send counts to backend for update
            fetch('update_inventory_count.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ counts: counts })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Inventory updated successfully!');
                    // No reload needed if only counts are displayed
                } else {
                    alert(data.error || 'Failed to update inventory.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while updating inventory.');
            });
        });
    </script>
</body>
</html> 