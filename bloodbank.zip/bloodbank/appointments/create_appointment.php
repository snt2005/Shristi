<?php
session_start();
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $donor_id = $_POST['donor_id'];
        $hospital_id = $_POST['hospital_id'];
        $appointment_date = $_POST['appointment_date'];

        $stmt = $pdo->prepare("INSERT INTO appointments (donor_id, hospital_id, appointment_date) 
                              VALUES (?, ?, ?)");
        $stmt->execute([$donor_id, $hospital_id, $appointment_date]);

        echo json_encode(['status' => 'success', 'message' => 'Appointment scheduled successfully']);
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}
?> 